package com.hotel.domain;

public class FloorPlan {
    private Integer hotelId;
    private Integer pictureId;
    private Integer floor;
}
