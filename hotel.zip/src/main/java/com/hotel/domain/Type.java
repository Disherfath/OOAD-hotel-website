package com.hotel.domain;

public class Type {
    private Integer id;
    private String roomType;
    private Float price;
}
