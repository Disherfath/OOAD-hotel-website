package com.hotel.domain;

import com.baomidou.mybatisplus.annotation.TableName;

import java.sql.Date;

@TableName(value = "ordering")
public class Order {
    private Integer id;
    private Integer consumerId;
    private Integer roomId;
    private Date establishTime;
    private Integer state;
    private float deal;
    private Date startTime;
    private Date endTime;
}
