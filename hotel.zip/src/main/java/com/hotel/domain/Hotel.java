package com.hotel.domain;

public class Hotel {
    private Integer id;
    private String location;
    private String city;
    private String telephone;
}
