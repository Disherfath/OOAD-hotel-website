package com.hotel.controller;

import com.hotel.dao.AccountDao;
import com.hotel.domain.Account;
import com.hotel.service.account.AccountService;
import com.hotel.service.account.impl.AccountServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("accounts")
public class AccountController {

    @Value("${server.port}")
    private Integer port;
    @Autowired
    private AccountServiceImpl accountService;
    @Autowired
    private AccountDao accountDao;

    @GetMapping("/{id}")
    public Account getById(@PathVariable Integer id) {
        System.out.println("id is" + id);
        System.out.println(port);
        return accountDao.selectById(id);
    }

    @GetMapping("/login")
    public Integer login(@RequestBody Account account) {
        System.out.println("userName is" + account.getUserName());
        System.out.println("password is" + account.getPassword());
        System.out.println(port);
        return accountService.login(account);
    }

    @PostMapping()
    public Boolean register(@RequestBody Account account) {
        System.out.println("userName is" + account.getUserName());
        System.out.println("password is" + account.getPassword());
        System.out.println(port);
        return accountService.register(account);
    }
}
