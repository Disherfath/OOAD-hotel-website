package com.hotel.domain;

public class Picture {
    private Integer id;
    private String content;
}
