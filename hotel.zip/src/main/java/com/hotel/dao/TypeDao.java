package com.hotel.dao;

public interface TypeDao {
}
