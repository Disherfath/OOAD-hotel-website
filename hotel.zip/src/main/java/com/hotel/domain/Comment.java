package com.hotel.domain;

public class Comment {
    private Integer id;
    private Integer consumerId;
    private Integer roomId;
}
