package com.hotel.dao;

public interface PictureDao {
}
