package com.hotel.domain;

public class Favorite {
    private Integer consumerId;
    private Integer roomId;
}
