package com.hotel.domain;

import java.sql.Date;

public class Message {
    private Integer id;
    private Integer consumerId;
    private String sender;
    private Date establishTime;
    private String content;
}
