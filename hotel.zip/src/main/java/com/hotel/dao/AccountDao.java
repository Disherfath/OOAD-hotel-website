package com.hotel.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hotel.domain.Account;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface AccountDao extends BaseMapper<Account> {
}
