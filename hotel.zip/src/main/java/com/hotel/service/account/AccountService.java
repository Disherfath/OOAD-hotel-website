package com.hotel.service.account;

import com.baomidou.mybatisplus.extension.service.IService;
import com.hotel.domain.Account;

public interface AccountService extends IService<Account> {
    public Integer login(Account account);
    public boolean register(Account account);
}
