package com.hotel.dao;

public interface RoomDao {
}
