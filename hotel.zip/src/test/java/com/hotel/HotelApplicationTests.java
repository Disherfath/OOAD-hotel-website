package com.hotel;

import com.hotel.controller.AccountController;
import com.hotel.dao.AccountDao;
import com.hotel.domain.Account;
import com.hotel.service.account.impl.AccountServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelApplicationTests {
    @Autowired
    private AccountDao accountDao;
    @Autowired
    private AccountServiceImpl accountService;
    @Test
    void contextLoads() {
        System.out.println(accountDao.selectById(1));
    }
    @Test
    void test1() {
        Account account = new Account();
        account.setUserName("dish111");
        account.setPassword("wuhu");
        System.out.println(accountService.login(account));
    }
}
