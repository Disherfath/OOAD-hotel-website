package com.hotel.dao;

public interface MessageDao {
}
