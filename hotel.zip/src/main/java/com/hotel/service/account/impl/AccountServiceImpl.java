package com.hotel.service.account.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hotel.dao.AccountDao;
import com.hotel.domain.Account;
import com.hotel.service.account.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl extends ServiceImpl<AccountDao, Account> implements AccountService {
    @Autowired
    AccountDao accountDao;

    //qw eq的第一个参数应该和数据库的列名一样
    @Override
    public Integer login(Account account) {
        QueryWrapper qw = new QueryWrapper();
        qw.eq("user_name", account.getUserName());
        qw.eq("password", account.getPassword());
        Account account1 = accountDao.selectOne(qw);
        if (account1 != null) {
            return account1.getId();
        }
        return -1;
    }

    @Override
    public boolean register(Account account) {
        //QueryWrapper qw = new QueryWrapper();
        //qw.eq("user_name", account.getUserName());
        //qw.eq("password", account.getPassword());
        accountDao.insert(account);
        return true;
    }
}
