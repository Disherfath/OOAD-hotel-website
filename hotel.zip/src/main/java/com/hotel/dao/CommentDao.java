package com.hotel.dao;

public interface CommentDao {
}
