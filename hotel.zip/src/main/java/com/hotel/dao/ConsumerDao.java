package com.hotel.dao;

public interface ConsumerDao {
}
