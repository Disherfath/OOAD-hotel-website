package com.hotel.dao;

public interface GiftDao {
}
