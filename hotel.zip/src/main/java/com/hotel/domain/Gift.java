package com.hotel.domain;

public class Gift {
    private Integer id;
    private String content;
    private Integer consumerId;
}
